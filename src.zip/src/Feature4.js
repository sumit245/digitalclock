import React from 'react'

export default function Feature4() {
    return (
        <div>
            <input />
        </div>
    )
}

// Insert push,shift,slice,splice,arr[ind]=value
// Delete pop,remove,splice,filter,reduce
// Traverse arr[index]
// Search filter,map,flatmap,reduce
// Sort filter,map,flatmap,reduce
